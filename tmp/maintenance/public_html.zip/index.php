<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wartungsarbeiten | Lababidi Bau</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --maroon: #800020;
            --black: #121212;
        }
        
        body {
            background-color: var(--black);
            color: white;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .maintenance-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), 
                        url('https://images.unsplash.com/photo-1605152276897-4f618f831968?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80') no-repeat center center;
            background-size: cover;
        }
        
        .maintenance-card {
            background-color: rgba(18, 18, 18, 0.9);
            border: 2px solid var(--maroon);
            border-radius: 10px;
            padding: 2rem;
            max-width: 700px;
            text-align: center;
            box-shadow: 0 0 30px rgba(128, 0, 32, 0.3);
        }
        
        .logo-placeholder {
            width: 120px;
            height: 120px;
            background-color: var(--maroon);
            border-radius: 50%;
            margin: 0 auto 1.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            font-weight: bold;
            color: white;
            border: 3px solid white;
        }
        
        h1 {
            color: var(--maroon);
            font-weight: 700;
            margin-bottom: 1.5rem;
        }
        
        .divider {
            height: 3px;
            background: linear-gradient(90deg, transparent, var(--maroon), transparent);
            margin: 1.5rem auto;
            width: 80%;
            opacity: 0.7;
        }
        
        .contact-info {
            margin-top: 2rem;
            padding: 1rem;
            background-color: rgba(128, 0, 32, 0.1);
            border-radius: 8px;
            border-left: 3px solid var(--maroon);
        }
        
        .btn-contact {
            background-color: var(--maroon);
            color: white;
            border: none;
            padding: 0.6rem 1.5rem;
            font-weight: 500;
            margin-top: 1rem;
            transition: all 0.3s;
        }
        
        .btn-contact:hover {
            background-color: #600018;
            transform: translateY(-2px);
        }
        
        .progress {
            height: 8px;
            margin: 2rem 0;
            background-color: #333;
        }
        
        .progress-bar {
            background-color: var(--maroon);
            animation: progress 2s ease-in-out infinite;
        }
        
        @keyframes progress {
            0% { width: 0%; }
            50% { width: 80%; }
            100% { width: 100%; }
        }
        
        .social-icons a {
            color: white;
            margin: 0 10px;
            font-size: 1.5rem;
            transition: color 0.3s;
        }
        
        .social-icons a:hover {
            color: var(--maroon);
        }
    </style>
</head>
<body>
    <div class="maintenance-container">
        <div class="container">
            <div class="row justify-content-center">
                <div class="maintenance-card">
                    <!-- <div class="logo-placeholder">LB</div> -->
                     <div class="logo">
                        <img src="imgs/logo.jpg" class="img-fluid">
                     </div>
                    
                    <h1 class="display-4">Wartungsarbeiten im Gange</h1>
                    
                    <p class="lead">Wir arbeiten derzeit an Verbesserungen unserer Website, um Ihnen ein noch besseres Erlebnis zu bieten.</p>
                    
                    <div class="divider"></div>
                    
                    <p>Die Website wird voraussichtlich bald wieder verfügbar sein. Vielen Dank für Ihr Verständnis und Ihre Geduld.</p>
                    
                    <div class="progress">
                        <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar"></div>
                    </div>
                    
                    <div class="contact-info">
                        <h3 class="h5">Bei dringenden Anliegen:</h3>
                        <p><i class="bi bi-envelope-fill"></i> <a href="mailto:info@lababidi-bau.de" class="text-white">info@lababidi-bau.de</a></p>
                        <p><i class="bi bi-telephone-fill"></i> <a href="tel:+491711172776" class="text-white">+49 171 1172776</a></p>
                        
                        <a href="mailto:info@lababidi-bau.de" class="btn btn-contact">
                            <i class="bi bi-envelope"></i> Kontakt aufnehmen
                        </a>
                    </div>
                    
                    
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>